import Navbar from "./Components/Navbar";
import React, { useEffect, useState } from 'react';
import Characters from "./Components/Characters";




function App() {

  const [characters, setCharacters] = useState([]);

  const url = "https://rickandmortyapi.com/api/character";

  const fetchPersonajes = (url) => {
    fetch(url)
      .then(Response => Response.json())
      .then(data => setCharacters(data.results))
      .catch(error => console.log(error))
  };

  useEffect(() => {
    fetchPersonajes(url);
  }, [])

  return (
    <>
      <Navbar titulo="rick and morty" />

      <div className="container">
        <Characters characters={characters}/>
      </div>
    </>
  );
}

export default App;
